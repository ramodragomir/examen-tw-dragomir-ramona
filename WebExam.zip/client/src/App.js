import './App.css';
import AddShip from './components/AddShip';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import 'bootstrap/dist/css/bootstrap.min.css';
import { Container } from 'react-bootstrap';
import Home from './components/Lista';
import EditShip from './components/EditShip';
import AddCrew from './components/AddCrew';
import EditCrew from './components/EditCrew';

function App() {
  return (
     <div className ="body">
      <Container>
        <Router>
          <Routes>
            <Route path = "/" element = {<Home/>}/>
            <Route path = "/editare/:id" element = {<EditShip/>}/>
            <Route path = "/adaugare" element = {<AddShip/>}/>
            <Route path = "/adaugare/copil/:id" element = {<AddCrew/>}/>
            <Route path = "/editare/copil/:id/parinte/:id2" element = {<EditCrew/>}/>
          </Routes>
        </Router>
      </Container>
    </div>
  );
}

export default App;

import { Form, Button, Container, Row, Col } from 'react-bootstrap'
import { useState,useEffect } from 'react'

function EditShip() {
    const [name, setname] = useState("");
    const [ displacement,setdisplacement] = useState("");

    const SERVER = `${window.location.protocol}//${window.location.hostname}:${window.location.port}`;

    useEffect(() => {
        const href = window.location.href;
        const id = href.split('/').at(-1);
        const fetchMovie = async () => {
          const res = await fetch(`${SERVER}/ships/${id}`);
          const data = await res.json();
          setname(data.name);
          setdisplacement(data.displacement);
        };
        fetchMovie();
      }, []);

    const saveHandler = (event) => {
        const href = window.location.href;
        const id = href.split('/').at(-1);
        fetch(`${SERVER}/ships/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                name: name, 
                displacement:displacement
             }),
          })
            .then((res) => res.json())
            .then((data)=>{window.location.href = '/';
            }).catch((e)=>alert(`Editare esuata!`));
    };
    return (<>
        <Container>
            <Row>
                <Col lg="4"></Col>
                <Col lg="4">
                    <h1 className = "mt-3">Editare</h1>
                    <Form>
                        <Form.Group className="mb-3 mt-3" controlId="formDescription">
                            <Form.Label>name</Form.Label>
                            <Form.Control type="text" placeholder="name" value={name} onChange={(e) => setname(e.target.value)} />
                            <Form.Label>displacement</Form.Label>
                            <Form.Control type="number" placeholder="displacement" value={displacement} onChange={(e) => setdisplacement(e.target.value)} />
                        </Form.Group>
                        <Button variant="primary" type="button" onClick={saveHandler} >
                            Salveaza
                        </Button>
                        <Button  variant="danger" type="button" onClick={()=>window.location.href = '/'} >
                            Anuleaza
                        </Button>
                    </Form>
                </Col>
                <Col lg="4"></Col>
            </Row>
        </Container>
    </>)
}

export default EditShip;
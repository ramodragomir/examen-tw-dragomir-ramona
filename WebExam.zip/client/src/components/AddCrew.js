import { Form, Button, Container, Row, Col } from 'react-bootstrap'
import { useState } from 'react'

function AddCrew() {
    const [name, setname] = useState("");
    const [role, setrole] = useState("");
    const SERVER = `${window.location.protocol}//${window.location.hostname}:${window.location.port}`;
    const addHandler = () => {
        const href = window.location.href;
        const id = href.split('/').at(-1);
        fetch(`${SERVER}/crew/ships/${id}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                name: name,
                role: role
            }),
        })
            .then((res) => res.json())
            .then((data) => {
                window.location.href = '/';
            }).catch((e) => console.log(`Adaugare ${name} esuata! ${e.message} ${role}`));
    };
    return (<>
        <Container>
            <Row>
                <Col lg="4"></Col>
                <Col lg="4">
                    <h1 className="mt-3">Adaugare</h1>
                    <Form>
                        <Form.Group className="mb-3 mt-3" controlId="formDescription">
                            <Form.Label>name</Form.Label>
                            <Form.Control type="text" placeholder="name" value={name} onChange={(e) => setname(e.target.value)} />
                            <Form.Label>role</Form.Label>
                            <Form.Select aria-label="Rol" value={role} onChange={(e) => setrole(e.target.value)}>
                                <option value="Captain">Captain</option>
                                <option value="Boatswain">Boatswain</option>
                                <option value="Navigator">Navigator</option>
                                <option value="Carpenter">Carpenter</option>
                            </Form.Select>
                        </Form.Group>
                        <Button variant="primary" type="button" onClick={addHandler} >
                            Adauga
                        </Button>
                        <Button variant="danger"type="button" onClick={()=>window.location.href = '/'} >
                            Anuleaza
                        </Button>
                    </Form>
                </Col>
                <Col lg="4"></Col>
            </Row>
        </Container>
    </>)
}

export default AddCrew;
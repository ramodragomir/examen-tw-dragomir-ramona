import { useState, useEffect } from 'react'
import { Table, Col, Row, Form, Button } from 'react-bootstrap'

function Lista() {
    const [lists, setLists] = useState([]);
    const SERVER = `${window.location.protocol}//${window.location.hostname}:${window.location.port}`;
    const [crew, setcrew] = useState([]);
    const [curentParent, setCurrentParent] = useState(0);
    const fetchData = async () => {
        const res = await fetch(`${SERVER}/ships/`);
        const data = await res.json();
        setLists(data.records)
    };

    useEffect(() => {
        fetchData();
    }, []);

    async function arataMembri(id) {
        setCurrentParent(id)
        const res = await fetch(`${SERVER}/crew/ships/${id}`);
        const data = await res.json();
        setcrew(data)
        console.log(data)
    }
    const stergeNava = (key) => {
        fetch(`${SERVER}/ships/${key}`, {
            method: 'DELETE',
        })
            .then((res) => res.json())
            .then((data) => {
                fetchData();
            });
    }
    const stergeMembru = (key) => {
        fetch(`${SERVER}/crew/${key}/ships/${curentParent}`, {
            method: 'DELETE',
        })
            .then((res) => res.json())
            .then((data) => {
            });
    }

    return (<>
        <Row  style={{marginTop:'10vh'}} >
            <Col lg="6">
                <h1>Nave</h1>
                <Button style={{marginBottom:20}} variant="secondary" type="button" onClick={() => window.location.href = '/adaugare'} >
                    Adauga o nava
                </Button>
                <p>Click pe nava pentru a vedea membrii.</p>
                <Table id='tabel' responsive>
                    <thead>
                        <tr>
                            <th>nume</th>
                            <th>displacement</th>
                            <th></th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        {lists.map((list) => (
                            <tr onClick={() => { arataMembri(list.id) }} key={list.id}>
                                <td>{list.name}</td>
                                <td>{list.displacement}</td>
                                <td><Button onClick={() => window.location.href = `/editare/${list.id}`}>editeaza</Button></td>
                                <td><Button variant="danger" onClick={() => stergeNava(list.id)}>sterge</Button></td>
                                <td><Button  variant="secondary" onClick={() => window.location.href = `/adaugare/copil/${list.id}`}>adauga membru</Button></td>
                            </tr>
                        )
                        )}
                    </tbody>
                </Table>
            </Col>
            <Col lg="6">
                <h1>Membri</h1>
                <p>{crew.length === 0 ? "Nava nu are membri" : `Membrii navei "${(lists.find((list) => list.id === crew[0].shipId)).name}" `}</p>
                <Table id='tabelcopil' responsive>
                    <thead>
                        <tr>
                            <th>nume</th>
                            <th>rol</th>
                        </tr>
                    </thead>
                    <tbody>
                        {crew.map((video) => (
                            <tr key={video.id}>
                                <td>{video.name}</td>
                                <td>{video.role}</td>
                                <td><Button onClick={() => window.location.href = `/editare/copil/${video.id}/parinte/${curentParent}`}>editeaza</Button></td>
                                <td><Button  variant="danger" onClick={() => stergeMembru(video.id)} style={{ backgroundColor: 'red' }}>sterge</Button></td>
                            </tr>
                        ))}
                    </tbody>
                </Table>
            </Col>
        </Row>
    </>)
}

export default Lista;
import { Form, Button, Container, Row, Col } from 'react-bootstrap'
import { useState,useEffect } from 'react'

function EditCrew() {
    const [name, setname] = useState("");
    const [role, setrole] = useState("");

    const SERVER = `${window.location.protocol}//${window.location.hostname}:${window.location.port}`;

    useEffect(() => {
        const href = window.location.href;
        const id = href.split('/').at(-1);
        const refId = href.split('/').at(-3);
        const fetchJob = async () => {
        const res = await fetch(`${SERVER}/crew/${refId}/ships/${id}`);
        const data = await res.json();
        setname(data.name);
        setrole(data.role);
        };
        fetchJob();
      }, []);

      const saveHandler = (event) => {
        const href = window.location.href;
        const id = href.split('/').at(-1);
        const refId = href.split('/').at(-3);
        fetch(`${SERVER}/crew/${refId}/ships/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                name: name, 
                role: role
             }),
          })
            .then((res) =>{ res.json(); })
            .then((data)=>{  window.location.href = '/';
            }).catch((e)=>console.log(`${e.message}`));
    };
    
    return (<>
        <Container>
            <Row>
                <Col lg="4"></Col>
                <Col lg="4">
                    <h1 className = "mt-3">Adaugare</h1>
                    <Form>
                        <Form.Group className="mb-3 mt-3" controlId="formDescription">
                            <Form.Label>name</Form.Label>
                            <Form.Control type="text" placeholder="name" value={name} onChange={(e) => setname(e.target.value)} />
                            <Form.Select aria-label="Rol" value={role} onChange={(e) => setrole(e.target.value)}>
                                <option value="Captain">Captain</option>
                                <option value="Boatswain">Boatswain</option>
                                <option value="Navigator">Navigator</option>
                                <option value="Carpenter">Carpenter</option>
                            </Form.Select>
                                </Form.Group>
                        <Button variant="primary" type="button" onClick={saveHandler} >
                            Salveaza
                        </Button>
                        <Button variant="danger" type="button" onClick={()=>window.location.href = '/'} >
                            Anuleaza
                        </Button>
                    </Form>
                </Col>
                <Col lg="4"></Col>
            </Row>
        </Container>
    </>)
}

export default EditCrew;
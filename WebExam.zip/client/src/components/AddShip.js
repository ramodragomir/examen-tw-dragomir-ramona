import { Form, Button, Container, Row, Col } from 'react-bootstrap'
import { useState } from 'react'

function AddShip() {
    const [name, setname] = useState("");
    const [ displacement,setdisplacement] = useState("");

    const SERVER = `${window.location.protocol}//${window.location.hostname}:${window.location.port}`;
    const addHandler = (event) => {
        fetch(`${SERVER}/ships`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
            name: name, 
            displacement:displacement
             }),
          })
            .then((res) => res.json())
            .then((displacement)=>{window.location.href = '/';
              console.log(`ship ${name} adaugat cu succes!`)
            }).catch((e)=>alert(`Adaugare esuata!`));
    };
    return (<>
        <Container>
            <Row>
                <Col lg="4"></Col>
                <Col lg="4">
                    <h1 className = "mt-3">Adaugare</h1>
                    <Form>
                        <Form.Group className="mb-3 mt-3" controlId="formDescription">
                            <Form.Label>name</Form.Label>
                            <Form.Control type="text" placeholder="name" value={name} onChange={(e) => setname(e.target.value)} />
                           <Form.Label>displacement</Form.Label>
                            <Form.Control type="number" placeholder="displacement" value={displacement} onChange={(e) => setdisplacement(e.target.value)} />
                        </Form.Group>
                        <Button variant="primary" type="button" onClick={addHandler} >
                            Adauga
                        </Button>
                        <Button variant="danger" type="button" onClick={()=>window.location.href = '/'} >
                            Anuleaza
                        </Button>
                    </Form>
                </Col>
                <Col lg="4"></Col>
            </Row>
        </Container>
    </>)
}

export default AddShip;